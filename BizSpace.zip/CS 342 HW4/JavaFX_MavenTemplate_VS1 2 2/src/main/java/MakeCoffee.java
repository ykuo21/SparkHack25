public class MakeCoffee {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Coffee order =new Sugar(new Cream( new ExtraShot(new BasicCoffee())));

        Coffee order2 = new ExtraShot(order);

        double cost = order2.makeCoffee();
        System.out.println("Total: $"+ String.format("%.2f", cost));
    }
}

interface Coffee{
    public double makeCoffee();
}

class BasicCoffee implements Coffee{

    private double cost = 4.50;

    @Override
    public double makeCoffee() {
        // TODO Auto-generated method stub
        System.out.println("Black Coffee: $4.50");

        return cost;
    }
}

abstract class CoffeeDecorator implements Coffee{
    protected Coffee specialCoffee;

    public CoffeeDecorator(Coffee specialCoffee) {
        this.specialCoffee = specialCoffee;
    }

    public double makeCoffee() {
        return specialCoffee.makeCoffee();
    }
}

class ExtraShot extends CoffeeDecorator{

    private double cost = 1.20;

    ExtraShot(Coffee specialCoffee){
        super(specialCoffee);
    }

    public double makeCoffee() {
        return specialCoffee.makeCoffee() + addShot();
    }

    private double addShot() {
        System.out.println(" + extra shot: $1.20");

        return cost;
    }
}

class Cream extends CoffeeDecorator{

    private double cost = .50;
    Cream(Coffee specialCoffee){
        super(specialCoffee);
    }

    public double makeCoffee() {
        return specialCoffee.makeCoffee() + addCream();
    }

    private double addCream() {

        System.out.println(" + cream: $.50");

        return cost;
    }
}

class Sugar extends CoffeeDecorator{

    private double cost = .50;

    Sugar(Coffee specialCoffee){
        super(specialCoffee);
    }

    public double makeCoffee() {
        return specialCoffee.makeCoffee()+ addSugar();
    }

    private double addSugar() {

        System.out.println(" + sugar: $.50");

        return cost;
    }
}

// new item - caramel
class Caramel extends CoffeeDecorator{

    private double cost = .75;

    Caramel(Coffee specialCoffee){
        super(specialCoffee);
    }

    public double makeCoffee() {
        return specialCoffee.makeCoffee()+ addCaramel();
    }

    private double addCaramel() {

        System.out.println(" + caramel: $.75");

        return cost;
    }
}

// new item - vanilla
class Vanilla extends CoffeeDecorator{

    private double cost = .60;

    Vanilla(Coffee specialCoffee){
        super(specialCoffee);
    }

    public double makeCoffee() {
        return specialCoffee.makeCoffee()+ addVanilla();
    }

    private double addVanilla() {

        System.out.println(" + vanilla: $.60");

        return cost;
    }
}




