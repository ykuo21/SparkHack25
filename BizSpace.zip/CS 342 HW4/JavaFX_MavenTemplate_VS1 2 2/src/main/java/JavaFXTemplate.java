import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.animation.RotateTransition;
import javafx.animation.SequentialTransition;
import javafx.application.Application;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;


public class JavaFXTemplate extends Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	//feel free to remove the starter code from this method
	@Override
	public void start(Stage primaryStage) throws Exception {
		try {
			// Load the FXML file
			Parent root = FXMLLoader.load(getClass().getResource("/FXML/coffee_shop.fxml"));

			// Set up the scene
			Scene scene = new Scene(root, 600, 400);

			// Add CSS stylesheet
			scene.getStylesheets().add(getClass().getResource("/styles/coffee_shop.css").toExternalForm());

			// Configure the stage
			primaryStage.setTitle("Coffee Shop Order");
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}
}
