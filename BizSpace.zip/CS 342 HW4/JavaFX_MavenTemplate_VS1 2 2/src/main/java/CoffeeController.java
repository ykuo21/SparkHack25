import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import javafx.scene.layout.VBox;

public class CoffeeController {
    @FXML
    private VBox addOnsBox;
    @FXML
    private TextArea orderDisplayArea;
    @FXML
    private Label totalCostLabel;
    @FXML
    private Button extraShotButton, creamButton, sugarButton, caramelButton, vanillaButton;

    // Counters for each add-on
    private int extraShotCount = 0;
    private int creamCount = 0;
    private int sugarCount = 0;
    private int caramelCount = 0;
    private int vanillaCount = 0;

    private static boolean complete = false;

    private Coffee currentOrder;

    @FXML
    public void initialize() {
        resetOrder();
    }

    @FXML
    public void addExtraShot() {
        extraShotCount++;
        updateOrder();
    }

    @FXML
    public void addCream() {
        creamCount++;
        updateOrder();
    }

    @FXML
    public void addSugar() {
        sugarCount++;
        updateOrder();
    }

    @FXML
    public void addCaramel() {
        caramelCount++;
        updateOrder();
    }

    @FXML
    public void addVanilla() {
        vanillaCount++;
        updateOrder();
    }

    @FXML
    public void resetOrder() {
        extraShotCount = 0;
        creamCount = 0;
        sugarCount = 0;
        caramelCount = 0;
        vanillaCount = 0;
        complete = false;
        extraShotButton.setDisable(false);
        creamButton.setDisable(false);
        sugarButton.setDisable(false);
        caramelButton.setDisable(false);
        vanillaButton.setDisable(false);
        currentOrder = new BasicCoffee();
        updateOrderDisplay();
    }

    @FXML
    public void completeOrder() {
        extraShotButton.setDisable(true);
        creamButton.setDisable(true);
        sugarButton.setDisable(true);
        caramelButton.setDisable(true);
        vanillaButton.setDisable(true);
        complete = true;
        updateOrderDisplay();
    }

    public void deleteOrder() {
        resetOrder();
    }

    private void updateOrder() {
        Coffee order = new BasicCoffee();

        // Add Extra Shots
        for (int i = 0; i < extraShotCount; i++) {
            order = new ExtraShot(order);
        }

        // Add Cream
        for (int i = 0; i < creamCount; i++) {
            order = new Cream(order);
        }

        // Add Sugar
        for (int i = 0; i < sugarCount; i++) {
            order = new Sugar(order);
        }

        // Add Caramel
        for (int i = 0; i < caramelCount; i++) {
            order = new Caramel(order);
        }

        // Add Vanilla
        for (int i = 0; i < vanillaCount; i++) {
            order = new Vanilla(order);
        }

        currentOrder = order;
        updateOrderDisplay();
    }

    private void updateOrderDisplay() {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream capturePrintStream = new PrintStream(outputStream);
        PrintStream originalPrintStream = System.out;
        System.setOut(capturePrintStream);

        double totalCost = currentOrder.makeCoffee();

        System.setOut(originalPrintStream);
        String orderDetails = outputStream.toString();

        // Build summary of quantities
        StringBuilder summary = new StringBuilder("Order Summary:\n");
        if (extraShotCount > 0) summary.append("Extra Shots: " + extraShotCount + "\n");
        if (creamCount > 0) summary.append("Cream: " + creamCount + "\n");
        if (sugarCount > 0) summary.append("Sugar: " + sugarCount + "\n");
        if (caramelCount > 0) summary.append("Caramel: " + caramelCount + "\n");
        if (vanillaCount > 0) summary.append("Vanilla: " + vanillaCount + "\n");

        if (complete) {
            orderDetails = orderDetails + String.format("Total: $%.2f\n", totalCost);
        }
        orderDisplayArea.setText(orderDetails + "\n" + summary.toString());

        totalCostLabel.setText(String.format("Total: $%.2f", totalCost));
    }
}