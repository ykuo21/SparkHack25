import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CoffeeDecoratorTest {

    @Test
    public void testBasicCoffeeCost() {
        Coffee basicCoffee = new BasicCoffee();
        assertEquals(4.50, basicCoffee.makeCoffee(), 0.001);
    }

    @Test
    public void testExtraShotAdding() {
        Coffee coffeeWithShot = new ExtraShot(new BasicCoffee());
        assertEquals(5.70, coffeeWithShot.makeCoffee(), 0.001);
    }

    @Test
    public void testCreamAdding() {
        Coffee coffeeWithCream = new Cream(new BasicCoffee());
        assertEquals(5.00, coffeeWithCream.makeCoffee(), 0.001);
    }

    @Test
    public void testSugarAdding() {
        Coffee coffeeWithSugar = new Sugar(new BasicCoffee());
        assertEquals(5.00, coffeeWithSugar.makeCoffee(), 0.001);
    }

    @Test
    public void testNewCoffeeDecoratorsCaramel() {
        Coffee coffeeWithCaramel = new Caramel(new BasicCoffee());
        assertEquals(5.25, coffeeWithCaramel.makeCoffee(), 0.001);
    }


    @Test
    public void testVanillaAdding() {
        Coffee coffeeWithShot = new Vanilla(new BasicCoffee());
        assertEquals(5.1, coffeeWithShot.makeCoffee(), 0.001);
    }


    @Test
    public void testCoffeeWithMultipleAddOns() {
        Coffee complexCoffee = new Sugar(new Cream(new ExtraShot(new BasicCoffee())));
        assertEquals(6.70, complexCoffee.makeCoffee(), 0.001);
    }

    @Test
    public void testCoffeeWithMultipleAddOns2() {
        Coffee complexCoffee = new Sugar(new Vanilla(new ExtraShot(new BasicCoffee())));
        assertEquals(6.80, complexCoffee.makeCoffee(), 0.001);
    }

    @Test
    public void testCoffeeWithMultipleAddOns3() {
        Coffee complexCoffee = new Caramel(new Cream(new Sugar(new Vanilla(new ExtraShot(new BasicCoffee())))));
        assertEquals(8.05, complexCoffee.makeCoffee(), 0.001);
    }


    @Test
    public void testComplexOrderWithNewDecorators() {
        Coffee complexCoffee = new Vanilla(new Caramel(new Sugar(new ExtraShot(new BasicCoffee()))));
        assertEquals(7.55, complexCoffee.makeCoffee(), 0.001);
    }

    @Test
    public void testRepeatedDecorators() {
        Coffee doubleShot = new ExtraShot(new ExtraShot(new BasicCoffee()));   // FIXME : Is it allow to add two same items?
        assertEquals(6.90, doubleShot.makeCoffee(), 0.001);
    }

    @Test
    public void testOrderOfDecoratorsDoesMatter() {
        Coffee order1 = new Cream(new Sugar(new ExtraShot(new BasicCoffee())));
        Coffee order2 = new Sugar(new Cream(new ExtraShot(new BasicCoffee())));
        assertEquals(order1.makeCoffee(), order2.makeCoffee());
    }
}