import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.io.File;
import java.io.FileInputStream;
import javafx.stage.FileChooser;

public class Controller {
    @FXML
    private Button BookingPromoButton;

    @FXML
    private void handle_bookingAndPromotion(ActionEvent event) {
        try {
            // Load the calendar FXML file.
            Parent calendarRoot = FXMLLoader.load(getClass().getResource("/FXML/calendar.fxml"));

            // Create a new Stage for the calendar window.
            Stage calendarStage = new Stage();
            calendarStage.setTitle("Calendar");

            // Create a Scene with the loaded FXML.
            Scene calendarScene = new Scene(calendarRoot);

            // Set the scene on the new stage and show it.
            calendarStage.setScene(calendarScene);
            calendarStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleExit(ActionEvent event) {
        Platform.exit();
    }

    public void displayImage() {

    }

}

