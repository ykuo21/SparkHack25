import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class JavaFXTemplate extends Application {
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		try {

			// Load the FXML file
			Parent root = FXMLLoader.load(getClass().getResource("/FXML/biz.fxml"));

			// Set up the scene
			Scene scene = new Scene(root, 600, 400);
			// Add CSS stylesheet
			scene.getStylesheets().add(getClass().getResource("/styles/biz.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setTitle("GT MENU");
			primaryStage.show();

		} catch (Exception e) {

			e.printStackTrace();
			System.exit(1);
		}
	}
}

